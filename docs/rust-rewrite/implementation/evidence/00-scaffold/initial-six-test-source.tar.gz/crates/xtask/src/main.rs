//! Repository-local development commands.
use std::{env, error::Error, fs, path::PathBuf, process::ExitCode};

fn schemas(check: bool) -> Result<(), Box<dyn Error>> {
    let root = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("../..");
    let path = root.join("schemas/range-error.json");
    let schema = schemars::schema_for!(memory_core::slice::RangeError);
    let output = format!("{}\n", serde_json::to_string_pretty(&schema)?);
    if check {
        if fs::read_to_string(path)? != output {
            return Err("schema drift: run cargo xtask schemas".into());
        }
    } else {
        fs::create_dir_all(root.join("schemas"))?;
        fs::write(path, output)?;
    }
    Ok(())
}

fn run() -> Result<(), Box<dyn Error>> {
    let args: Vec<_> = env::args().skip(1).collect();
    match args.as_slice() {
        [command] if command == "schemas" => schemas(false),
        [command, flag] if command == "schemas" && flag == "--check" => schemas(true),
        _ => Err("usage: cargo xtask schemas [--check]".into()),
    }
}

fn main() -> ExitCode {
    match run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("{error}");
            ExitCode::FAILURE
        }
    }
}
