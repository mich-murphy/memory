//! Synchronous, I/O-free scaffold for the capture domain.
//!
//! No production capture model is implemented in slice 0.
pub mod slice;
