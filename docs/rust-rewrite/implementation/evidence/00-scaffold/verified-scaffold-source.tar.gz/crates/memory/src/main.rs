//! Reserved command entry point; no capture commands exist in slice 0.
use std::process::ExitCode;

fn main() -> ExitCode {
    // Fail explicitly rather than simulate successful capture or restore.
    ExitCode::from(78)
}
