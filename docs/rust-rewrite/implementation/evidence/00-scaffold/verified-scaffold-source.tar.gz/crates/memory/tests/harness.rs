//! Diagnostic checks of counter/DST seams, not daemon footprint acceptance.
use memory::environment::{Clock, Counters, FileSystem, Store};
use std::collections::BTreeMap;

#[derive(Default)]
struct Fake {
    counters: Counters,
    now: u64,
    objects: BTreeMap<u64, Vec<u8>>,
    lose_reply: bool,
}
impl Clock for Fake {
    fn monotonic_ns(&self) -> u64 {
        self.now
    }
    fn wall_ns(&self) -> i128 {
        i128::from(self.now)
    }
}
impl FileSystem for Fake {
    type Error = ();
    fn stat_len(&mut self, _source: u64) -> Result<u64, ()> {
        self.counters.stats += 1;
        Ok(30_000)
    }
    fn read(&mut self, _source: u64, range: std::ops::Range<u64>) -> Result<Vec<u8>, ()> {
        let len = range.end.checked_sub(range.start).ok_or(())?;
        self.counters.bytes_read += len;
        Ok(vec![0; usize::try_from(len).map_err(|_| ())?])
    }
}
impl Store for Fake {
    type Body = Vec<u8>;
    type Error = ();
    fn create(&mut self, key: u64, body: Vec<u8>) -> Result<(), ()> {
        self.counters.puts += 1;
        self.objects.entry(key).or_insert(body);
        if self.lose_reply { Err(()) } else { Ok(()) }
    }
}

#[test]
fn counters_detect_each_wrapped_operation() -> Result<(), ()> {
    let mut fake = Fake::default();
    for source in 0..30_000 {
        fake.stat_len(source)?;
    }
    assert_eq!(fake.counters.stats, 30_000);
    fake.read(0, 0..59_000)?;
    fake.read(0, 0..(68 * 1024))?;
    assert_eq!(fake.counters.bytes_read, 59_000 + 68 * 1024);
    fake.now += 60_000_000_000;
    fake.counters.wakeups += 1;
    assert_eq!(fake.monotonic_ns(), 60_000_000_000);
    assert_eq!(fake.wall_ns(), 60_000_000_000);
    assert_eq!(fake.counters.wakeups, 1);
    Ok(())
}

#[test]
fn lost_reply_is_visible_and_duplicate_create_preserves_first_body() -> Result<(), ()> {
    let mut fake = Fake {
        lose_reply: true,
        ..Fake::default()
    };
    assert_eq!(fake.create(7, vec![1, 2]), Err(()));
    assert_eq!(fake.objects.get(&7), Some(&vec![1, 2]));
    fake.lose_reply = false;
    fake.create(7, vec![9])?;
    assert_eq!(fake.objects.get(&7), Some(&vec![1, 2]));
    assert_eq!(fake.counters.puts, 2);
    Ok(())
}

#[test]
fn scaffold_binary_refuses_capture_instead_of_success() -> std::io::Result<()> {
    let output = std::process::Command::new(env!("CARGO_BIN_EXE_memory"))
        .arg("daemon")
        .output()?;
    assert_eq!(output.status.code(), Some(78));
    assert!(output.stdout.is_empty());
    assert!(output.stderr.is_empty());
    Ok(())
}
