//! Trait seams for seed-replayable simulation, independent of runtime selection.
//!
//! These are minimal scaffold interfaces, not a storage or retry framework.
//! Runtime adapters must remain safe Rust: do not weaken `forbid(unsafe_code)` to
//! add flock/F_FULLFSYNC. Select safe dependency APIs and review their contracts.

/// Monotonic and wall time are separate and controlled by the simulator.
pub trait Clock {
    /// Monotonic elapsed nanoseconds, excluding sleep on the target hosts.
    fn monotonic_ns(&self) -> u64;
    /// Wall nanoseconds; never an ordering authority.
    fn wall_ns(&self) -> i128;
}

/// Minimal filesystem seam; production metadata types arrive in a later slice.
pub trait FileSystem {
    /// Adapter's closed error type.
    type Error;
    /// Observe a synthetic/source handle's length without opening content.
    ///
    /// # Errors
    /// Returns the adapter's error on an unavailable source.
    fn stat_len(&mut self, source: u64) -> Result<u64, Self::Error>;
    /// Read a bounded range through the counter seam.
    ///
    /// # Errors
    /// Returns the adapter's error for unavailable or invalid ranges.
    fn read(&mut self, source: u64, range: std::ops::Range<u64>) -> Result<Vec<u8>, Self::Error>;
}

/// Store seam, generic over the future authorized body capability.
///
/// There is deliberately no production implementation or raw-byte body constructor.
/// The later adapter must bind Body to Authorized<Redacted<Bytes>>.
pub trait Store {
    /// The authorized body capability (synthetic only in scaffold tests).
    type Body;
    /// Adapter's closed error type.
    type Error;
    /// Immutable conditional creation; a simulator may lose the reply after landing.
    ///
    /// # Errors
    /// Returns the adapter's closed error, including ambiguous replies.
    fn create(&mut self, key: u64, body: Self::Body) -> Result<(), Self::Error>;
}

/// Per-wrapper observations, never a claim about unwrapped system calls.
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub struct Counters {
    /// Stat calls through the filesystem seam.
    pub stats: u64,
    /// Bytes returned through the filesystem seam.
    pub bytes_read: u64,
    /// Store calls, including failed/lost-reply attempts.
    pub puts: u64,
    /// Explicit simulator timer wakeups.
    pub wakeups: u64,
}
