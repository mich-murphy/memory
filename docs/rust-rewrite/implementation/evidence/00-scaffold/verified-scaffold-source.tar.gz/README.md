# Rust slice 0 (not a collector)

All commands use the repository's **locked Nix shell**, Rust/cargo 1.99.0.
No rustup/global installs. From repository root:

```sh
nix develop --max-jobs 2 --cores 2
cd rust
cargo xtask schemas                 # regenerate committed diagnostic schema
PROPERTY_CASES=2000 bash scripts/gates.sh
# CI invocation: PROPERTY_CASES=500 bash scripts/gates.sh
```

`artifacts/status.tsv` preserves each gate exit status; logs and seeds remain in
`artifacts/`. Replay with `PROPERTY_SEED=<recorded> PROPERTY_CASES=2000`.
The coverage tool is isolated in `nix develop .#coverage`: the default shell must
not become unavailable when an upstream instrumented test build fails. A missing
coverage command is a blocked gate, **not** success. Coverage floor is a target
until the first valid measurement is recorded; do not call it measured.

The binary deliberately exits 78, including for unknown commands; it cannot
silently simulate capture/restore. The only core behavior is checked byte slicing.
Its Hegel and proptest checks compare against an independent iterator oracle.
The filesystem counters and lost-reply fixture validate the test seams, not real
daemon performance, commit protocol, or the DESIGN section 15 properties.
`proptest-state-machine` is available for property 4 in slice 2; its existence is
not a state-machine correctness claim. No capture/privacy/locator gate is faked.

`cargo deny` checks workspace licenses/advisories/sources; a separate pure-core
ban invocation excludes dev dependencies. Dependency bans cannot prohibit
`std::fs`/`std::net`; review core source boundaries too. Later runtimes must use
safe APIs for flock/F_FULLFSYNC and must never suppress `forbid(unsafe_code)`.

Monthly diagnostic: `cargo mutants -p memory-core --jobs 2` (not run at bootstrap).
No workflow has been added; hosted CI execution remains parent-owned.
