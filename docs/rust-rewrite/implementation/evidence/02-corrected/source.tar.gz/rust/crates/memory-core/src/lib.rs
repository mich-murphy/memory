//! Synchronous, I/O-free capture decisions and protected-source transformations.
//!
//! Runtime adapters must supply validated observations; this crate performs no I/O.
pub mod coalescer;
pub mod domain;
pub mod planner;
pub mod privacy;
pub mod slice;
